
package com.example.app.demo.model.app;


import java.util.ArrayList;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter

public final class Views{
	private ArrayList<String> table;
}
