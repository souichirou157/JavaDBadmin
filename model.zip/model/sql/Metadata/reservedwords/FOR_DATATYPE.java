package com.example.app.demo.model.sql.Metadata.reservedwords;

public enum FOR_DATATYPE {
	TINYINT,MEDIUMINT,BIGINT,INT,	INTEGER
}
