package com.example.app.demo.model.sql.Metadata.reservedwords;

public enum FOR_VALUES {

	NULL,TRUE,FALSE
	
	
}
