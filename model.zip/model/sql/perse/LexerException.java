package com.example.app.demo.model.sql.perse;

public class LexerException extends PersingException{

	public LexerException(String message) {
		super(message);
	}
}
