package com.example.app.demo.model.sql.perse;



public class NotFoundSymbolException
     extends RuntimeException

{
	NotFoundSymbolException(String message){
		
		super(message);
	}
}
