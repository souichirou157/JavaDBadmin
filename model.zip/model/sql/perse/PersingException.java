package com.example.app.demo.model.sql.perse;

public class PersingException 

extends RuntimeException
{
	
	public  PersingException (String message) {
		new Exception(message);
	}
	
	
	
}
