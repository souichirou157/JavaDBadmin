"use strict";
//
//function log(){
//				document.querySelector('#statement_area').value = document.querySelector('#statement_area').value.replace(/,/g, '#');
//				document.querySelector('#statement_area').value = document.querySelector('#statement_area').value.replace(/ /g, '!');
//			
//				console.log(window.document.querySelector('#statement_area').value);
//}
